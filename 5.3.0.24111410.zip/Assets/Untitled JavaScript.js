@input Asset.Texture hintImage1
// @input Component.Image hintImageComponent1
// @input SceneObject tapToRevealImage1
// @input SceneObject blurImage1

// @input Asset.Texture hintImage2
// @input Component.Image hintImageComponent2
// @input SceneObject tapToRevealImage2
// @input SceneObject blurImage2

// @input Asset.Texture hintImage3
// @input Component.Image hintImageComponent3
// @input SceneObject tapToRevealImage3
// @input SceneObject blurImage3

// @input Asset.Texture hintImage4
// @input Component.Image hintImageComponent4
// @input SceneObject tapToRevealImage4
// @input SceneObject blurImage4

// @input Asset.Texture hintImage5
// @input Component.Image hintImageComponent5
// @input SceneObject tapToRevealImage5
// @input SceneObject blurImage5

// @input Asset.Texture hintImage6
// @input Component.Image hintImageComponent6
// @input SceneObject tapToRevealImage6
// @input SceneObject blurImage6

// Image Marker Inputs (Add these)
// @input imageMarker1: SceneObject;
// @input imageMarker2: SceneObject;
// @input imageMarker3: SceneObject;
// @input imageMarker4: SceneObject;
// @input imageMarker5: SceneObject;
// @input imageMarker6: SceneObject;

// Array to track if a marker has been tapped (add this)
var markersTapped = [false, false, false, false, false, false];

// Function to handle tap events for a specific marker
function onMarkerTap(markerIndex) {
  // Check if the corresponding marker is being tracked AND it hasn't been tapped yet
  if (script["imageMarker" + markerIndex].tracking && !markersTapped[markerIndex - 1]) {
    // Hide the tap to reveal image
    script["tapToRevealImage" + markerIndex].enabled = false;
    // Show the hint image
    script["hintImageComponent" + markerIndex].mainPass.baseTex = script["hintImage" + markerIndex];
    script["hintImageComponent" + markerIndex].getSceneObject().enabled = true;

    // Mark the marker as tapped
    markersTapped[markerIndex - 1] = true;
  }
}

// Create tap events for each marker
for (let i = 1; i <= 6; i++) {
  script.createEvent("TapEvent").bind(onMarkerTap.bind(null, i));
}

