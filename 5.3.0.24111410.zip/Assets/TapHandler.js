// @input Asset.Texture hintImage1
// @input Component.Image hintImageComponent1
// @input SceneObject tapToRevealImage1
// @input SceneObject blurImage1

// @input Asset.Texture hintImage2
// @input Component.Image hintImageComponent2
// @input SceneObject tapToRevealImage2
// @input SceneObject blurImage2

// @input Asset.Texture hintImage3
// @input Component.Image hintImageComponent3
// @input SceneObject tapToRevealImage3
// @input SceneObject blurImage3

// @input Asset.Texture hintImage4
// @input Component.Image hintImageComponent4
// @input SceneObject tapToRevealImage4
// @input SceneObject blurImage4

// @input Asset.Texture hintImage5
// @input Component.Image hintImageComponent5
// @input SceneObject tapToRevealImage5
// @input SceneObject blurImage5

// @input Asset.Texture hintImage6
// @input Component.Image hintImageComponent6
// @input SceneObject tapToRevealImage6
// @input SceneObject blurImage6

// Function to handle tap events for a specific marker
function onMarkerTap(markerIndex) {
  // Hide the tap to reveal image
  script["tapToRevealImage" + markerIndex].enabled = false;
  // Show the hint image
  script["hintImageComponent" + markerIndex].mainPass.baseTex = script["hintImage" + markerIndex];
  script["hintImageComponent" + markerIndex].getSceneObject().enabled = true;
}

// Create tap events for each marker
for (let i = 1; i <= 6; i++) {
  script.createEvent("TapEvent").bind(onMarkerTap.bind(null, i));
}



